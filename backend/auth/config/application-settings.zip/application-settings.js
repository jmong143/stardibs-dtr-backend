var Config = {

    projectName : "",
    projectBaseURL : "ipostmo-auth"

}

module.exports = Config;
